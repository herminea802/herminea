# # CpeError

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cod** | **string** | Codigo de error encontrado | [optional]
**msg** | **string** | Descripción de error encontrado | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
