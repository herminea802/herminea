<?php
/**
 * Created by PhpStorm.
 * User: Administrador
 * Date: 15/02/2018
 * Time: 05:35 PM
 */
namespace Greenter\XMLSecLibs\Certificate;

/**
 * Class X509ContentType
 */
abstract class X509ContentType
{
    const PEM = 1;
    const CER = 2;
}